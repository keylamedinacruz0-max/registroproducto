package com.example.registrocliente1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
