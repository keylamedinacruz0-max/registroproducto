import 'package:flutter/material.dart';
import 'models/producto.dart';
import 'entidad_page.dart';

void main() {
  runApp(const InventarioApp());
}

class InventarioApp extends StatelessWidget {
  const InventarioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'InventarioApp',

      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color.fromARGB(255, 192, 115, 211),
        ),
        useMaterial3: true,
      ),

      home: const RegistroProductoPage(),
    );
  }
}

class RegistroProductoPage extends StatefulWidget {
  const RegistroProductoPage({super.key});

  @override
  State<RegistroProductoPage> createState() =>
      _RegistroProductoPageState();
}

class _RegistroProductoPageState
    extends State<RegistroProductoPage> {

  // Lista temporal de productos
  final List<Producto> _productos = <Producto>[];

  // Clave para validar el formulario
  final _formKey = GlobalKey<FormState>();

  // Controladores
  final TextEditingController _codigoController =
      TextEditingController();

  final TextEditingController _nombreController =
      TextEditingController();

  final TextEditingController _precioController =
      TextEditingController();

  // Variables de los controles
  String? _categoria;

  int _stock = 0;

  String _estado = 'Disponible';

  DateTime? _fechaIngreso;

  bool _perecible = false;

  @override
  void dispose() {
    _codigoController.dispose();
    _nombreController.dispose();
    _precioController.dispose();

    super.dispose();
  }

  // Seleccionar fecha
  Future<void> _seleccionarFecha() async {
    final DateTime hoy = DateTime.now();

    final DateTime? fecha = await showDatePicker(
      context: context,
      initialDate: hoy,
      firstDate: DateTime(2000),
      lastDate: hoy,
    );

    if (fecha != null) {
      setState(() {
        _fechaIngreso = fecha;
      });
    }
  }

  // Registrar producto
  void _registrarProducto() {

    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_fechaIngreso == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Seleccione la fecha de ingreso',
          ),
        ),
      );

      return;
    }

    final double? precio =
        double.tryParse(_precioController.text);

    if (precio == null || precio <= 0) {
      return;
    }

    final Producto producto = Producto(
      codigo: _codigoController.text,
      nombre: _nombreController.text,
      categoria: _categoria!,
      precio: precio,
      stock: _stock,
      estado: _estado,
      fechaIngreso: _fechaIngreso!,
      perecible: _perecible,
    );

    setState(() {
      _productos.add(producto);
    });

    _limpiarFormulario();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Producto registrado correctamente',
        ),
      ),
    );
  }

  // Limpiar formulario
  void _limpiarFormulario() {

    _codigoController.clear();
    _nombreController.clear();
    _precioController.clear();

    setState(() {
      _categoria = null;
      _stock = 0;
      _estado = 'Disponible';
      _fechaIngreso = null;
      _perecible = false;
    });
  }

  // Ir a la tabla
  void _verProductos() {

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EntidadPage(
          productos: _productos,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text(
          'InventarioApp',
        ),

        centerTitle: true,

        actions: [
          IconButton(
            onPressed: _verProductos,
            icon: const Icon(
              Icons.inventory,
            ),
          ),
        ],
      ),

      body: Form(
        key: _formKey,

        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),

          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [

              const Text(
                'Registro de Productos',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 20),

              // CÓDIGO
              TextFormField(
                controller: _codigoController,

                keyboardType:
                    TextInputType.number,

                maxLength: 6,

                decoration: const InputDecoration(
                  labelText: 'Código del producto',
                  hintText: 'Ejemplo: 123456',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(
                    Icons.qr_code,
                  ),
                ),

                validator: (value) {

                  if (value == null ||
                      value.isEmpty) {
                    return 'Ingrese el código';
                  }

                  if (!RegExp(
                    r'^\d{6}$',
                  ).hasMatch(value)) {
                    return 'Debe contener exactamente 6 dígitos';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 10),

              // NOMBRE
              TextFormField(
                controller: _nombreController,

                textCapitalization:
                    TextCapitalization.words,

                decoration: const InputDecoration(
                  labelText: 'Nombre del producto',
                  hintText: 'Ejemplo: Arroz',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(
                    Icons.shopping_bag,
                  ),
                ),

                validator: (value) {

                  if (value == null ||
                      value.trim().isEmpty) {
                    return 'Ingrese el nombre';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 16),

              // CATEGORÍA
              DropdownButtonFormField<String>(
                value: _categoria,

                decoration: const InputDecoration(
                  labelText: 'Categoría',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(
                    Icons.category,
                  ),
                ),

                items: const [
                  DropdownMenuItem(
                    value: 'Abarrotes',
                    child: Text('Abarrotes'),
                  ),
                  DropdownMenuItem(
                    value: 'Bebidas',
                    child: Text('Bebidas'),
                  ),
                  DropdownMenuItem(
                    value: 'Limpieza',
                    child: Text('Limpieza'),
                  ),
                  DropdownMenuItem(
                    value: 'Golosinas',
                    child: Text('Golosinas'),
                  ),
                  DropdownMenuItem(
                    value: 'Lácteos',
                    child: Text('Lácteos'),
                  ),
                  DropdownMenuItem(
                    value: 'Otro',
                    child: Text('Otro'),
                  ),
                   DropdownMenuItem(
                    value: 'Cereales',
                    child: Text('Cereales'),
                  ),
                ],
                

                onChanged: (value) {
                  setState(() {
                    _categoria = value;
                  });
                },

                validator: (value) {
                  if (value == null) {
                    return 'Seleccione una categoría';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 16),

              // PRECIO
              TextFormField(
                controller: _precioController,

                keyboardType:
                    const TextInputType.numberWithOptions(
                  decimal: true,
                ),

                decoration: const InputDecoration(
                  labelText: 'Precio unitario (S/)',
                  hintText: 'Ejemplo: 12.50',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(
                    Icons.attach_money,
                  ),
                ),

                validator: (value) {

                  if (value == null ||
                      value.isEmpty) {
                    return 'Ingrese el precio';
                  }

                  final double? precio =
                      double.tryParse(value);

                  if (precio == null) {
                    return 'Ingrese un número válido';
                  }

                  if (precio <= 0) {
                    return 'El precio debe ser mayor que 0';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 20),

              // STOCK
              Text(
                'Cantidad en stock: $_stock',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),

              Slider(
                value: _stock.toDouble(),

                min: 0,
                max: 80,
                divisions: 100,

                label: _stock.toString(),

                onChanged: (value) {
                  setState(() {
                    _stock = value.round();
                  });
                },
              ),

              const SizedBox(height: 10),

              // ESTADO
              const Text(
                'Estado',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              SegmentedButton<String>(
                segments: const [
                  ButtonSegment<String>(
                    value: 'Disponible',
                    label: Text('Disponible'),
                    icon: Icon(
                      Icons.check_circle,
                    ),
                  ),

                  ButtonSegment<String>(
                    value: 'Agotado',
                    label: Text('Agotado'),
                    icon: Icon(
                      Icons.cancel,
                    ),
                  ),
                ],

                selected: <String>{
                  _estado,
                },

                onSelectionChanged:
                    (Set<String> seleccion) {

                  setState(() {
                    _estado = seleccion.first;
                  });
                },
              ),

              const SizedBox(height: 20),

              // FECHA
              ListTile(
                contentPadding: EdgeInsets.zero,

                leading: const Icon(
                  Icons.calendar_month,
                ),

                title: const Text(
                  'Fecha de ingreso',
                ),

                subtitle: Text(
                  _fechaIngreso == null
                      ? 'No seleccionada'
                      : '${_fechaIngreso!.day}/'
                        '${_fechaIngreso!.month}/'
                        '${_fechaIngreso!.year}',
                ),

                trailing: ElevatedButton(
                  onPressed: _seleccionarFecha,
                  child: const Text(
                    'Seleccionar',
                  ),
                ),
              ),

              const SizedBox(height: 10),

              // PERECIBLE
              SwitchListTile(
                contentPadding: EdgeInsets.zero,

                title: const Text(
                  '¿Producto perecible?',
                ),

                subtitle: Text(
                  _perecible
                      ? 'Sí'
                      : 'No',
                ),

                value: _perecible,

                onChanged: (value) {
                  setState(() {
                    _perecible = value;
                  });
                },
              ),

              const SizedBox(height: 20),

              // BOTÓN REGISTRAR
              SizedBox(
                width: double.infinity,

                child: ElevatedButton.icon(
                  onPressed: _registrarProducto,

                  icon: const Icon(
                    Icons.save,
                  ),

                  label: const Text(
                    'Registrar producto',
                  ),

                  style: ElevatedButton.styleFrom(
                    padding:
                        const EdgeInsets.symmetric(
                      vertical: 15,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // BOTÓN VER PRODUCTOS
              SizedBox(
                width: double.infinity,

                child: OutlinedButton.icon(
                  onPressed: _verProductos,

                  icon: const Icon(
                    Icons.table_view,
                  ),

                  label: Text(
                    'Ver productos (${_productos.length})',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}