import 'package:flutter/material.dart';
import 'models/producto.dart';

class EntidadPage extends StatelessWidget {
  const EntidadPage({
    super.key,
    required this.productos,
  });

  final List<Producto> productos;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Productos registrados (${productos.length})',
        ),
        centerTitle: true,
      ),

      body: productos.isEmpty
          ? const Center(
              child: Text(
                'No hay productos registrados',
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
            )
          : SingleChildScrollView(
              scrollDirection: Axis.horizontal,

              child: Padding(
                padding: const EdgeInsets.all(16),

                child: DataTable(
                  columns: const [
                    DataColumn(
                      label: Text(
                        'Código',
                      ),
                    ),

                    DataColumn(
                      label: Text(
                        'Nombre',
                      ),
                    ),

                    DataColumn(
                      label: Text(
                        'Categoría',
                      ),
                    ),

                    DataColumn(
                      label: Text(
                        'Precio (S/)',
                      ),
                    ),

                    DataColumn(
                      label: Text(
                        'Stock',
                      ),
                    ),

                    DataColumn(
                      label: Text(
                        'Estado',
                      ),
                    ),
                  ],

                  rows: productos.map(
                    (producto) {
                      return DataRow(
                        cells: [
                          DataCell(
                            Text(
                              producto.codigo,
                            ),
                          ),

                          DataCell(
                            Text(
                              producto.nombre,
                            ),
                          ),

                          DataCell(
                            Text(
                              producto.categoria,
                            ),
                          ),

                          DataCell(
                            Text(
                              'S/ ${producto.precio.toStringAsFixed(2)}',
                            ),
                          ),

                          DataCell(
                            Text(
                              producto.stock.toString(),
                            ),
                          ),

                          DataCell(
                            Text(
                              producto.estado,
                            ),
                          ),
                        ],
                      );
                    },
                  ).toList(),
                ),
              ),
            ),
    );
  }
}